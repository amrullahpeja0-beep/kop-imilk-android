package id.kopimilk.business.data
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="sales")
data class Sale(@PrimaryKey(autoGenerate=true) val id:Long=0, val menu:String, val quantity:Int, val unitPrice:Long, val total:Long, val createdAt:Long=System.currentTimeMillis(), val synced:Boolean=false)
@Entity(tableName="expenses")
data class Expense(@PrimaryKey(autoGenerate=true) val id:Long=0, val title:String, val amount:Long, val createdAt:Long=System.currentTimeMillis(), val synced:Boolean=false)

@Dao interface BusinessDao {
 @Insert suspend fun addSale(item:Sale)
 @Insert suspend fun addExpense(item:Expense)
 @Query("SELECT * FROM sales ORDER BY createdAt DESC") fun sales():Flow<List<Sale>>
 @Query("SELECT * FROM expenses ORDER BY createdAt DESC") fun expenses():Flow<List<Expense>>
 @Query("SELECT COALESCE(SUM(total),0) FROM sales WHERE createdAt >= :start AND createdAt < :end") fun omzet(start:Long,end:Long):Flow<Long>
 @Query("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE createdAt >= :start AND createdAt < :end") fun biaya(start:Long,end:Long):Flow<Long>
}
@Database(entities=[Sale::class,Expense::class],version=1,exportSchema=false)
abstract class BusinessDatabase:RoomDatabase(){
 abstract fun dao():BusinessDao
 companion object {
  @Volatile private var INSTANCE:BusinessDatabase?=null
  fun get(context:Context)=INSTANCE?: synchronized(this){INSTANCE?:Room.databaseBuilder(context.applicationContext,BusinessDatabase::class.java,"kop-imilk.db").build().also{INSTANCE=it}}
 }
}
