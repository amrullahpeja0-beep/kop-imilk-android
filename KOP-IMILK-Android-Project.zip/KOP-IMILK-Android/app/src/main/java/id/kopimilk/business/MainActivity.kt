package id.kopimilk.business
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import id.kopimilk.business.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.*

private fun rp(n:Long)=NumberFormat.getCurrencyInstance(Locale("id","ID")).format(n)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App(BusinessDatabase.get(this).dao())}}
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(dao:BusinessDao){
 val scope= rememberCoroutineScope()
 val sales by dao.sales().collectAsState(initial=emptyList())
 val expenses by dao.expenses().collectAsState(initial=emptyList())
 var tab by remember{mutableIntStateOf(0)}
 var menu by remember{mutableStateOf("Kopi Latte")}
 var qty by remember{mutableStateOf("1")}
 var price by remember{mutableStateOf("10000")}
 var title by remember{mutableStateOf("")}
 var amount by remember{mutableStateOf("")}
 val start=remember{Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis}
 val end=start+86400000L
 val omzet by dao.omzet(start,end).collectAsState(initial=0L)
 val biaya by dao.biaya(start,end).collectAsState(initial=0L)
 MaterialTheme(colorScheme=darkColorScheme(primary=androidx.compose.ui.graphics.Color(0xFF9A6846))){
 Scaffold(topBar={TopAppBar(title={Column{Text("KOP-IMILK",fontWeight=FontWeight.Black);Text("BUSINESS MANAGER",style=MaterialTheme.typography.labelSmall)}})},
 bottomBar={NavigationBar{listOf("Beranda","Input","Riwayat").forEachIndexed{i,s->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={},label={Text(s)})}}}){pad->
 when(tab){
 0->LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Text("Ringkasan hari ini",style=MaterialTheme.typography.titleLarge)}
  item{Card{Column(Modifier.padding(16.dp)){Text("Omzet");Text(rp(omzet),style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(8.dp));Text("Pengeluaran: ${rp(biaya)}");Text("Selisih sementara: ${rp(omzet-biaya)}")}}}
  item{Text("Menu KOP-IMILK",fontWeight=FontWeight.Bold)}
  items(listOf("Kopi Latte","Americano","Gula Aren","Mocha","Kopi Susu Creamy")){ListItem(headlineContent={Text(it)})}
  item{Text("Selisih sementara belum memperhitungkan HPP bahan yang belum dicatat sebagai pengeluaran.",style=MaterialTheme.typography.bodySmall)}
 }
 1->LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{Text("Catat penjualan",style=MaterialTheme.typography.titleLarge)}
  item{var expanded by remember{mutableStateOf(false)};ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}){OutlinedTextField(menu,{},{label={Text("Menu")},readOnly=true,modifier=Modifier.menuAnchor().fillMaxWidth()});ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){listOf("Kopi Latte","Americano","Gula Aren","Mocha","Kopi Susu Creamy").forEach{DropdownMenuItem(text={Text(it)},onClick={menu=it;expanded=false})}}}}
  item{OutlinedTextField(qty,{qty=it.filter(Char::isDigit)},label={Text("Jumlah gelas")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth())}
  item{OutlinedTextField(price,{price=it.filter(Char::isDigit)},label={Text("Harga per gelas")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth())}
  item{Button(onClick={val q=qty.toIntOrNull()?:0;val p=price.toLongOrNull()?:0;if(q>0&&p>0)scope.launch{dao.addSale(Sale(menu=menu,quantity=q,unitPrice=p,total=q*p));qty="1"}},modifier=Modifier.fillMaxWidth()){Text("Simpan penjualan")}}
  item{Divider();Text("Catat pengeluaran",style=MaterialTheme.typography.titleLarge)}
  item{OutlinedTextField(title,{title=it},label={Text("Keperluan")},modifier=Modifier.fillMaxWidth())}
  item{OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Nominal rupiah")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth())}
  item{OutlinedButton(onClick={val a=amount.toLongOrNull()?:0;if(title.isNotBlank()&&a>0)scope.launch{dao.addExpense(Expense(title=title,amount=a));title="";amount=""}},modifier=Modifier.fillMaxWidth()){Text("Simpan pengeluaran")}}
 }
 else->LazyColumn(Modifier.fillMaxSize().padding(pad)){
  item{Text("Riwayat penjualan",Modifier.padding(16.dp),style=MaterialTheme.typography.titleLarge)}
  items(sales){ListItem(headlineContent={Text("${it.menu} × ${it.quantity}")},trailingContent={Text(rp(it.total))})}
  item{Text("Riwayat pengeluaran",Modifier.padding(16.dp),style=MaterialTheme.typography.titleLarge)}
  items(expenses){ListItem(headlineContent={Text(it.title)},trailingContent={Text(rp(it.amount))})}
 }
 }
 }}
}
