# KOP-IMILK Android — proyek awal v0.1.0

Proyek native Android dengan Kotlin, Jetpack Compose, dan Room.

## Yang sudah disiapkan
- Dashboard omzet, pengeluaran, dan selisih sementara hari ini
- Input penjualan lima menu KOP-IMILK
- Input pengeluaran
- Riwayat transaksi
- Database lokal Room agar input tetap berjalan offline
- Dependensi Firebase Auth dan Firestore sudah dimasukkan sebagai fondasi cloud

## Yang belum aktif
Sinkronisasi cloud belum diimplementasikan. Firebase perlu proyek milik pengguna, file `app/google-services.json`, aturan keamanan Firestore, autentikasi, serta sinkronisasi dua arah dan penanganan konflik. Jangan menganggap data sudah tersinkron sebelum pengujian berhasil.

Stok otomatis, resep/HPP, laporan periode, ekspor, backup/restore, dan login juga masih tahap berikutnya.

## Build APK
1. Buka folder proyek ini menggunakan Android Studio stabil.
2. Gunakan JDK 17 dan Android SDK 35.
3. Tunggu Gradle Sync.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug di `app/build/outputs/apk/debug/app-debug.apk`.

Proyek sumber ini belum berupa APK siap instal dan belum diuji build di lingkungan Android SDK.
